# llm-wiki starter

本仓库将 Karpathy 在《LLM Wiki》中提出的模式，实例化为一个可以直接落地的本地优先知识系统：

- `raw/`：不可变原始资料层
- `wiki/`：由 LLM 维护的 Markdown Wiki 层
- `AGENTS.md`：约束 LLM 行为的系统 schema 层

## 立即执行

1. 将新资料放入 `raw/inbox/`
2. 打开本仓库至 Codex / Claude Code / 其他代码代理
3. 明确指令：`请严格按照 AGENTS.md 初始化并处理 raw/inbox 中的首个来源`
4. 审阅代理产出的变更：`wiki/sources/`、`wiki/entities/`、`wiki/concepts/`、`wiki/_meta/index.md`、`wiki/_meta/log.md`
5. 继续执行：
   - `请回答问题：…… 并将结果保存到 wiki/questions/`
   - `请执行一次 lint，并输出 contradictions / stale / orphan / gaps 报告`

## 核心约束

- 原始资料永不修改
- 一切知识沉淀进 Wiki，不仅停留在对话里
- 每次 ingest / query / lint 都要更新 `index.md` 和 `log.md`
- 每个页面必须带 frontmatter，且必须能追溯来源
- 所有自动化缓存都只能写入 `state/`，并且必须可重建

## 目录说明

- `AGENTS.md`：代理执行规则
- `docs/EXECUTION_PLAN_zh.md`：30 天执行计划
- `docs/ARCHITECTURE.md`：系统设计
- `BACKLOG.csv`：优先级任务列表
- `templates/`：页面模板
