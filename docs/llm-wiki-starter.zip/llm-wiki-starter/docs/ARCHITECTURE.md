# 系统设计

## 1. 目标

将文章中的抽象模式，实例化为一个“本地优先、Markdown 优先、Git 管理、LLM 维护”的知识系统。系统不在查询时反复从原始文档临时拼装答案，而是先把知识编译进 Wiki，再从 Wiki 进行回答与再沉淀。

## 2. 设计范围

默认支持以下场景：

- 个人研究 / 长期专题学习
- 小团队内部知识沉淀
- 竞品研究、尽调、项目档案、课程笔记

默认规模：

- MVP：20–100 个来源
- 扩展：100–500 个来源
- 单人或 1–3 人小组协作

## 3. 三层架构

### 3.1 原始资料层（raw）
职责：
- 保存网页、论文、会议纪要、图片、数据摘录等原始输入
- 只读、不可编辑、可审计

建议结构：
- `raw/inbox/`：待处理
- `raw/sources/`：已登记原件
- `raw/assets/`：图片、附件、本地资源

### 3.2 Wiki 层（wiki）
职责：
- 对来源做结构化总结
- 维护实体页、概念页、综合页、问题页、时间线
- 维持跨页链接、一致性与增量演化

建议结构：
- `wiki/sources/`
- `wiki/entities/`
- `wiki/concepts/`
- `wiki/questions/`
- `wiki/syntheses/`
- `wiki/timelines/`
- `wiki/_meta/index.md`
- `wiki/_meta/log.md`

### 3.3 Schema 层（AGENTS.md）
职责：
- 约束代理的页面格式、命名、工作流、引用与日志行为
- 防止代理退化为普通问答机器人
- 让跨会话维护保持一致

## 4. 运行组件

### 4.1 人机界面
- Wiki 浏览器：Obsidian
- 代码代理：Codex / Claude Code / 同类代理
- 来源采集：浏览器裁剪、手工放入 `raw/inbox/`

### 4.2 编排层
建议以后续工程实现为 Python CLI：
- `llmwiki ingest`
- `llmwiki ask`
- `llmwiki lint`
- `llmwiki rebuild-index`
- `llmwiki sync-state`

### 4.3 派生状态层
`state/` 仅保存可重建缓存：
- `source_manifest.jsonl`
- `wiki.db`（页面、链接、来源、lint 结果）
- `lint-latest.json`

`state/` 不得成为事实源，只能作为加速层。

## 5. 数据契约

### 5.1 来源 ID
格式：
- `SRC-YYYYMMDD-XXX`

要求：
- 全局唯一
- 与来源总结页一一对应
- 所有页面的 `source_refs` 必须引用该 ID

### 5.2 页面 frontmatter
统一字段：
- `page_type`
- `title`
- `slug`
- `status`
- `created_at`
- `updated_at`
- `source_refs`
- `entity_refs`
- `concept_refs`
- `confidence`
- `review_after`

### 5.3 链接图
全部页面之间的知识连接，均通过 `[[wiki links]]` 表示。图结构是 lint 和导航的基础：

- 入链数为 0：候选 orphan
- 高频共现但无页面：候选 gap
- 共享来源却结论不一致：候选 contradiction

## 6. 核心算法

### 6.1 Ingest
输入：新来源  
输出：来源总结页 + 多个增量更新页

步骤：
1. 解析来源文本与附件引用
2. 生成来源总结
3. 提取实体、概念、主张、未决问题
4. 在 Wiki 中执行实体对齐与页面更新
5. 写入 index / log
6. 产出变更集供人工审阅

### 6.2 Query
输入：用户问题  
输出：答案 + 可选落盘页面

步骤：
1. 先读 `index.md`
2. 选取相关页面
3. 聚合跨页信息并回答
4. 将高价值答案保存为新页面
5. 更新 index / log

### 6.3 Lint
输入：当前 Wiki  
输出：健康检查报告

算法思路：
1. 解析 frontmatter、链接和来源引用
2. 基于图计算 orphan / hub / disconnected components
3. 基于 `review_after` 与新增来源检测 stale 页面
4. 基于共享主题与不一致结论检测 contradiction 候选
5. 基于高频链接占位与未建页项检测 gaps

## 7. 工程路线

### 阶段 A：无代码 MVP
- 直接使用 Obsidian + 代理 + 本仓库模板
- 目标是先跑通真实知识沉淀闭环

### 阶段 B：CLI 自动化
- 将 ingest / ask / lint 固化为脚本或命令
- 引入 `state/` 作为派生缓存
- 减少人工重复操作

### 阶段 C：检索增强
- 规模较小时，仅使用 `index.md`
- 规模扩大后，接入本地 Markdown 搜索引擎

### 阶段 D：发布与协作
- Git 分支与 PR 审阅
- 多人协作写入策略
- 导出报告、幻灯、专题摘要

## 8. 关键质量指标

- 单次 ingest 能稳定更新来源页、索引、日志与至少 1 个相关知识页
- 任意高价值 query 都可以沉淀为问题页或综合页
- orphan 页面占比持续下降
- 陈旧页与争议页可被周期性识别
- 所有重要结论均可追溯至来源 ID

## 9. 非目标

以下内容不进入 MVP：
- 复杂权限体系
- 大规模云端多租户架构
- 端到端 OCR 平台
- 先上嵌入、后补 Wiki 的 RAG-first 方案
